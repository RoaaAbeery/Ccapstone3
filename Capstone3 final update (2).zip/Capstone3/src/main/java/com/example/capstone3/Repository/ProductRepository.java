package com.example.capstone3.Repository;

import com.example.capstone3.Model.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProductRepository extends JpaRepository<Product,Integer> {
    Product findProductById(Integer id);
    List<Product> findProductByCategory(String category);

    List<Product> findProductsBySupplierId(Integer id);



    @Query("SELECT p from Product p where p.price BETWEEN :min AND :max")
    List<Product> findProductByRangeOfPrice(Double min,Double max);
}
