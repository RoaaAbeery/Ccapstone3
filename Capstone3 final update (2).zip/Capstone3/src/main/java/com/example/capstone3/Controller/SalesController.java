package com.example.capstone3.Controller;


import com.example.capstone3.DTO.SalesDTO;
import com.example.capstone3.Model.Product;
import com.example.capstone3.Model.Sales;
import com.example.capstone3.Service.ProductService;
import com.example.capstone3.Service.SalesService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;

@RestController
@RequestMapping("api/v1/sales")
@RequiredArgsConstructor
public class SalesController {

    private final SalesService salesService;


    @GetMapping("/get")
    public ResponseEntity getSales() {
        return ResponseEntity.status(200).body(salesService.getSales());
    }

    @PostMapping("/add")
    public ResponseEntity addSales(@Valid @RequestBody SalesDTO sale) {
        salesService.addSale(sale);
        return ResponseEntity.status(200).body("Sales added");
    }

    @PutMapping("/update/{id}")
    public ResponseEntity updateSales(@PathVariable Integer id, @Valid @RequestBody SalesDTO sales) {
        salesService.updateSale(id, sales);
        return ResponseEntity.status(200).body("Sales updated");
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity deleteSales(@PathVariable Integer id) {
        salesService.deleteSale(id);
        return ResponseEntity.status(200).body("Sales deleted");
    }

    @GetMapping("/dates/between/{startDate}/{endDate}")
    public ResponseEntity findSalesByDatesBetween(@PathVariable LocalDate startDate, @PathVariable LocalDate endDate) {

        return ResponseEntity.status(200).body(salesService.findSalesBetween(startDate, endDate));
    }


    @GetMapping("/dates/after/{date}")
    public ResponseEntity findSalesByDatesAfter(@PathVariable LocalDate date) {

        return ResponseEntity.status(200).body(salesService.findSalesByDateAfter(date));
    }

    @GetMapping("/date/{date}")
    public ResponseEntity findSalesByDatesEquals(@PathVariable LocalDate date) {

        return ResponseEntity.status(200).body(salesService.findSalesByDateEqual(date));
    }
    @GetMapping("/dates/before/{date}")
    public ResponseEntity findSalesByDatesBefore(@PathVariable LocalDate date) {

        return ResponseEntity.status(200).body(salesService.findSalesBefore(date));
    }



}
