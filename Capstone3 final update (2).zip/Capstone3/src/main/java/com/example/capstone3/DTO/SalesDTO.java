package com.example.capstone3.DTO;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.time.LocalDate;

@Data
@RequiredArgsConstructor
public class SalesDTO {

    @JsonFormat(pattern = "yyyy-MM-dd")
    @NotNull
    private LocalDate date;
    private double totalSales;
    @NotNull
    private Integer company_id;
}
