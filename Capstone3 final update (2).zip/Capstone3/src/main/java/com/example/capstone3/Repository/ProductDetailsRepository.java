package com.example.capstone3.Repository;

import com.example.capstone3.Model.ProductDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Set;

@Repository
public interface ProductDetailsRepository extends JpaRepository<ProductDetails,Integer> {

    ProductDetails findProductDetailsById(Integer id);
    Set<ProductDetails> findProductDetailsByProductId(Integer id);

}
