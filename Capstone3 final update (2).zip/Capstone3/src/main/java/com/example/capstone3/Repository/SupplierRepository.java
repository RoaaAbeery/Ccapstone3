package com.example.capstone3.Repository;

import com.example.capstone3.Model.Product;
import com.example.capstone3.Model.Supplier;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Set;

@Repository
public interface SupplierRepository extends JpaRepository<Supplier,Integer> {
    Supplier findSupplierById(Integer id);
    Set<Supplier> findSuppliersByCostsEquals(double cost);

}
