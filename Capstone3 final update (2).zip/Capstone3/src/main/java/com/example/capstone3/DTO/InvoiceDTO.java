package com.example.capstone3.DTO;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;
import java.util.Set;

@Data
@AllArgsConstructor
public class InvoiceDTO {
    @NotNull(message = "customer id should not be empty")
    private Integer customer_id;
    @NotNull(message = "product Detail should not be empty")
    private Set<ProductDetailsDTO> productDetailsDTO;
    @NotNull
    private double totalPrice;

}
