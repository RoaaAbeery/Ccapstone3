package com.example.capstone3.Service;

import com.example.capstone3.ApiException.ApiException;
import com.example.capstone3.Model.*;
import com.example.capstone3.Repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Set;

@Service
@RequiredArgsConstructor
public class ReportService {
    private final ReportRepository reportRepository;
    private final CustomerRepository customerRepository;
    private final EmployeeRepository employeeRepository;
    private final CompanyRepository companyRepository;
    private final ExpensesRepository expensesRepository;
    private final InvoiceRepository invoiceRepository;
    private final InventoryRepository inventoryRepository;
    private final ProductRepository productRepository;
    private final SalesRepository salesRepository;
    private final SupplierRepository supplierRepository;

    public List<Report> getReports(){
        return reportRepository.findAll();
    }

    public void addReports(Report reports){
        reportRepository.save(reports);
    }


    public void updateReports(Integer id, Report reports){
        Report reports1=reportRepository.findReportsById(id);
        if (reports1 == null){
            throw new ApiException("Reports not found");
        }
        reportRepository.save(reports1);
    }

    public void deleteReports(Integer id){
        Report reports1=reportRepository.findReportsById(id);
        if (reports1 == null){
            throw new ApiException("Reports not found");
        }
        reportRepository.delete(reports1);
    }

    public void assignReportToCustomer(Integer report_id,Integer customer_id){
        Report report=reportRepository.findReportsById(report_id);
        Customer customer=customerRepository.findCustomerById(customer_id);
        if(report_id==null||customer==null){
            throw new ApiException("you can't complete assign");
        }
        customer.getReport().add(report);
        report.getCustomer().add(customer);
        customerRepository.save(customer);
        reportRepository.save(report);
    }
    public void assignReportToEmployee(Integer report_id,Integer employee_id){
        Report report=reportRepository.findReportsById(report_id);
        Employee employee=employeeRepository.findEmployeeById(employee_id);
        if(report_id==null||employee==null){
            throw new ApiException("you can't complete assign");
        }
        employee.getReport().add(report);
        report.getEmployee().add(employee);
        employeeRepository.save(employee);
        reportRepository.save(report);
    }

    public void assignReportToCompany(Integer report_id,Integer company_id){
        Report report=reportRepository.findReportsById(report_id);
        Company company=companyRepository.findCompanyById(company_id);
        if(report_id==null||company==null){
            throw new ApiException("you can't complete assign");
        }
        company.getReport().add(report);
        report.getCompanies().add(company);
        companyRepository.save(company);
        reportRepository.save(report);
    }
    public void assignReportToExpenses(Integer report_id,Integer expenses_id){
        Report report=reportRepository.findReportsById(report_id);
        Expenses expenses=expensesRepository.findExpensesById(expenses_id);
        if(report_id==null||expenses==null){
            throw new ApiException("you can't complete assign");
        }
        expenses.getReport().add(report);
        report.getExpenses().add(expenses);
        expensesRepository.save(expenses);
        reportRepository.save(report);
    }
    public void assignReportToInvoice(Integer report_id,Integer invoice_id){
        Report report=reportRepository.findReportsById(report_id);
        Invoice invoice=invoiceRepository.findInvoiceById(invoice_id);
        if(report_id==null||invoice==null){
            throw new ApiException("you can't complete assign");
        }
        invoice.getReport().add(report);
        report.getInvoices().add(invoice);
        invoiceRepository.save(invoice);
        reportRepository.save(report);
    }
    public void assignReportToInventory(Integer report_id,Integer inventory_id){
        Report report=reportRepository.findReportsById(report_id);
        Inventory inventory=inventoryRepository.findInventoryById(inventory_id);
        if(report_id==null||inventory==null){
            throw new ApiException("you can't complete assign");
        }
        inventory.getReport().add(report);
        report.getInventory().add(inventory);
        inventoryRepository.save(inventory);
        reportRepository.save(report);
    }
    public void assignReportToProduct(Integer report_id,Integer product_id){
        Report report=reportRepository.findReportsById(report_id);
        Product product=productRepository.findProductById(product_id);
        if(report_id==null||product==null){
            throw new ApiException("you can't complete assign");
        }
        product.getReport().add(report);
        report.getProduct().add(product);
        productRepository.save(product);
        reportRepository.save(report);
    }
    public void assignReportToSales(Integer report_id,Integer sales_id){
        Report report=reportRepository.findReportsById(report_id);
        Sales sales=salesRepository.findSalesById(sales_id);
        if(report_id==null||sales==null){
            throw new ApiException("you can't complete assign");
        }
        sales.getReport().add(report);
        report.getSales().add(sales);
        salesRepository.save(sales);
        reportRepository.save(report);
    }

    public void assignReportToSupplier(Integer report_id,Integer supplier_id){
        Report report=reportRepository.findReportsById(report_id);
        Supplier supplier=supplierRepository.findSupplierById(supplier_id);
        if(report_id==null||supplier==null){
            throw new ApiException("you can't complete assign");
        }
        supplier.getReport().add(report);
        report.getSupplier().add(supplier);
        supplierRepository.save(supplier);
        reportRepository.save(report);
    }

    public Set<Report> getReportByCompany(Integer company_id){
        Company company=companyRepository.findCompanyById(company_id);
        if(company==null){
            throw new ApiException("Company not found");
        }
        return company.getReport();
    }
    public Set<Report> getReportByCustomer(Integer customer_id){
        Customer customer=customerRepository.findCustomerById(customer_id);
        if(customer==null){
            throw new ApiException("Customer not found");
        }
        return customer.getReport();
    }
    public Set<Report> getReportByEmployee(Integer employee_id){
        Employee employee=employeeRepository.findEmployeeById(employee_id);
        if(employee==null){
            throw new ApiException("Employee not found");
        }
        return employee.getReport();
    }
    public Set<Report> getReportByExpenses(Integer expenses_id){
        Expenses expenses=expensesRepository.findExpensesById(expenses_id);
        if(expenses==null){
            throw new ApiException("expenses not found");
        }
        return expenses.getReport();
    }
    public List<Report> findReportBetween(LocalDate start, LocalDate end){
        List<Report> reports=reportRepository.findReportsByDate(start,end);
        if (reports==null){
            throw new ApiException("There is no report for these dates");
        }   return reports;
    }
    public List<Report> findReportByDateEqual(LocalDate date){
        List< Report> report=reportRepository.findReportByDateEquals(date);
        if (report == null){
            throw new ApiException("Invalid dates or no Report available for this date");
        }
        return report;
    }
    public Set<Report> getReportByInventory(Integer inventory_id){
        Inventory inventory=inventoryRepository.findInventoryById(inventory_id);
        if(inventory==null){
            throw new ApiException("inventory not found");
        }
        return inventory.getReport();
    }
    public Set<Report> getReportByInvoice(Integer invoice_id){
        Invoice invoice=invoiceRepository.findInvoiceById(invoice_id);
        if(invoice_id==null){
            throw new ApiException("invoice not found");
        }
        return invoice.getReport();
    }


}
