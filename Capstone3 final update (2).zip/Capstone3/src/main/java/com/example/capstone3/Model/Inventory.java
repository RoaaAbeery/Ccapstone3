package com.example.capstone3.Model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Set;

@AllArgsConstructor
@NoArgsConstructor
@Entity
@Setter
@Getter
public class Inventory {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
//    private String Description;
//    private String Status;

//    @OneToMany(cascade = CascadeType.ALL,mappedBy = "inventory")
//    private Set<Product> product;


    @OneToMany(cascade = CascadeType.ALL,mappedBy = "inventory")
    private Set<Supplier> supplier;

    @ManyToOne
    @JoinColumn(name = "company_id",referencedColumnName = "id")
    @JsonIgnore
    private Company company;

    @ManyToMany
    @JsonIgnore
    private Set<Report> report;


}
