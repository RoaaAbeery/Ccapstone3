package com.example.capstone3.Controller;

import com.example.capstone3.Model.Report;
import com.example.capstone3.Service.ReportService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;

@RestController
@RequestMapping("api/v1/report")
@RequiredArgsConstructor
public class ReportController {
    private final ReportService reportService;

    @GetMapping("/get")
    public ResponseEntity getReports(){
        return ResponseEntity.status(200).body(reportService.getReports());
    }
    @PostMapping("/add")
    public ResponseEntity addReports(@Valid @RequestBody Report reports){
        reportService.addReports(reports);
        return ResponseEntity.status(200).body("report added");
    }

    @PutMapping("/update/{id}")
    public ResponseEntity updateReports(@PathVariable Integer id, @Valid @RequestBody Report reports){
        reportService.updateReports(id, reports);
        return ResponseEntity.status(200).body("Reports updated");
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity deleteReports(@PathVariable Integer id){
        reportService.deleteReports(id);
        return ResponseEntity.status(200).body("Reports deleted");

    }
    @PutMapping("/assignCustomer/{report_id}/{customer_id}")
    public ResponseEntity assignReportToCustomer(@PathVariable Integer report_id,@PathVariable Integer customer_id){
        reportService.assignReportToCustomer(report_id, customer_id);
        return ResponseEntity.status(HttpStatus.OK).body("assign done");
    }
    @PutMapping("/assignEmployee/{report_id}/{employee_id}")
    public ResponseEntity assignReportToEmployee(@PathVariable Integer report_id,@PathVariable Integer employee_id){
        reportService.assignReportToEmployee(report_id, employee_id);
        return ResponseEntity.status(HttpStatus.OK).body("assign done");
    }

    @PutMapping("/assignCompany/{report_id}/{company_id}")
    public ResponseEntity assignReportToCompany(@PathVariable Integer report_id,@PathVariable Integer company_id){
        reportService.assignReportToCompany(report_id,company_id);
        return ResponseEntity.status(HttpStatus.OK).body("assign done");
    }
    @PutMapping("/assignExpense/{report_id}/{expenses_id}")
    public ResponseEntity assignReportToExpenses(@PathVariable Integer report_id,@PathVariable Integer expenses_id){
        reportService.assignReportToExpenses(report_id, expenses_id);
        return ResponseEntity.status(HttpStatus.OK).body("assign done");
    }
    @PutMapping("/assignInventory/{report_id}/{inventory_id}")
    public ResponseEntity assignReportToInventory(@PathVariable Integer report_id,@PathVariable Integer inventory_id){
        reportService.assignReportToInventory(report_id, inventory_id);
        return ResponseEntity.status(HttpStatus.OK).body("assign done");
    }
    @PutMapping("/assignInvoice/{report_id}/{invoice_id}")
    public ResponseEntity assignReportToInvoice(@PathVariable Integer report_id,@PathVariable Integer invoice_id){
        reportService.assignReportToInvoice(report_id, invoice_id);
        return ResponseEntity.status(HttpStatus.OK).body("assign done");
    }
    @PutMapping("/assignProduct/{report_id}/{product_id}")
    public ResponseEntity assignReportToProduct(@PathVariable Integer report_id,@PathVariable Integer product_id){
        reportService.assignReportToProduct(report_id, product_id);
        return ResponseEntity.status(HttpStatus.OK).body("assign done");
    }
    @PutMapping("/assignSales/{report_id}/{sales_id}")
    public ResponseEntity assignReportToSales(@PathVariable Integer report_id,@PathVariable Integer sales_id){
        reportService.assignReportToSales(report_id, sales_id);
        return ResponseEntity.status(HttpStatus.OK).body("assign done");
    }
    @PutMapping("/assignSupplier/{report_id}/{supplier_id}")
    public ResponseEntity assignReportToSupplier(@PathVariable Integer report_id,@PathVariable Integer supplier_id){
        reportService.assignReportToSupplier(report_id, supplier_id);
        return ResponseEntity.status(HttpStatus.OK).body("assign done");
    }

    @GetMapping("/geReportByCompany/{company_id}")
    public ResponseEntity geReportByCompany(@PathVariable Integer company_id){
        return ResponseEntity.status(HttpStatus.OK).body(reportService.getReportByCompany(company_id));
    }

    @GetMapping("/getReportByCustomer/{customer_id}")
    public ResponseEntity getReportByCustomer(@PathVariable Integer customer_id){
        return ResponseEntity.status(HttpStatus.OK).body(reportService.getReportByCustomer(customer_id));
    }

    @GetMapping("/getReportByEmployee/{employee_id}")
    public ResponseEntity getReportByEmployee(@PathVariable Integer employee_id){
        return ResponseEntity.status(HttpStatus.OK).body(reportService.getReportByEmployee(employee_id));
    }

    @GetMapping("/getReportByExpenses/{expenses_id}")
    public ResponseEntity getReportByExpenses(@PathVariable Integer expenses_id){
        return ResponseEntity.status(HttpStatus.OK).body(reportService.getReportByExpenses(expenses_id));
    }

    @GetMapping("/dates/between/{startDate}/{endDate}")
    public ResponseEntity findReportByDatesBetween(@PathVariable LocalDate startDate, @PathVariable LocalDate endDate) {

        return ResponseEntity.status(200).body(reportService.findReportBetween(startDate,endDate));
    }

    @GetMapping("/date/{date}")
    public ResponseEntity findReportByDatesEquals(@PathVariable LocalDate date) {

        return ResponseEntity.status(200).body(reportService.findReportByDateEqual(date));
    }
    @GetMapping("/getReportByInventory/{inventory_id}")
    public ResponseEntity getReportByInventory(@PathVariable Integer inventory_id){
        return ResponseEntity.status(HttpStatus.OK).body(reportService.getReportByInventory(inventory_id));
    }
    @GetMapping("/getReportByInvoice/{invoice_id}")
    public ResponseEntity getReportByInvoice(@PathVariable Integer invoice_id){
        return ResponseEntity.status(HttpStatus.OK).body(reportService.getReportByInvoice(invoice_id));
    }
}
